import React, { Component } from 'react'
import { BrowserRouter, Route } from 'react-router-dom'
import { connect } from 'react-redux'
import  * as actions from '../../actions'


import Landing from '../LandingPage'
import StudentHomePage from '../StudentHomePage'
import SignupPage from '../SignupPage'
import LoginPage from '../LoginPage'


import './app.css'



class App extends Component {
  componentDidMount(){
    this.props.fetchUser()
  }

  render() {
    return (
      <div className="app">
        <BrowserRouter>
          <React.Fragment>
           
            <Route exact path="/" component = {Landing} />
            <Route exact path="/home" component={StudentHomePage} />
            <Route exact path="/signup" component={SignupPage} />
            <Route exact path="/login" component={LoginPage} />
           
          </React.Fragment>
        </BrowserRouter>
      </div>
    )
  }
}

export default connect(null, actions) (App)
