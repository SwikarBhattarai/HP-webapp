import React from 'react'
import { Jumbotron, Button, Row, Col } from 'reactstrap';
import  feature_1 from '../../assets/feature-1.jpg'
import  feature_2 from '../../assets/feature-2.jpg'
import  feature_3 from '../../assets/feature-3.jpg'
import Header from '../../components/Header'
import Footer from '../../components/Footer'
import './style.css'


const Landing = () => (
  <div className="root">
    <Header />
    <Jumbotron>
      <h1 className="display-4">Welcome!</h1>
      <p className="lead">The first online platform in Nepal to provide cheapest, fastest and efficient way of learning to Nepalese students.</p>
      <hr className="my-2" />
      <p className="lead">
        <Button color="primary">Learn More</Button>
      </p>
    </Jumbotron>
    <div className="container">
      <div className="row">
        <div className="col">
          <img src={feature_1} alt="feature_1"  className="feature img-thumbnail rounded" />
          <h3>Expert Instruction</h3>
        </div>
        <div className="col">   
          <img src={feature_2} alt="feature_2"  className="feature img-thumbnail" />
          <h3>Nepali Language</h3>
        </div>
        <div className="col">
          <img src={feature_3} alt="feature_3"  className="feature img-thumbnail" />
          <h3>Cheaper Price</h3>
        </div>
      </div>
    </div>
    <Footer />
  </div>
)

export default Landing