import React from 'react';
import { Button, Form, FormGroup, Label, Input, FormText } from 'reactstrap';

export default class SignupPage extends React.Component {
  render() {
    return (
      <Form style={{ width:'50%'}} action="/signup">
        <FormGroup>
          <Label for="exampleEmail">Username</Label>
          <Input type="name" name="name" id="exampleEmail" placeholder="with a placeholder" />
        </FormGroup>
        <FormGroup>
          <Label for="examplePassword">Password</Label>
          <Input type="password" name="password" id="examplePassword" placeholder="password placeholder" />
        </FormGroup>
        <FormGroup check>
          <Label check>
            <Input type="checkbox" />{' '}
            Check me out
          </Label>
        </FormGroup>
        <Button type="submit">Sign Up</Button>
      </Form>
    );
  }
}