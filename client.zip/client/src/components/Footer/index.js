import React from 'react'
import './style.css'
const FooterNav = () =>(
  <footer className="footer">
    <div className="container" style={{textAlign:"center"}}>
      <span className="text-muted" >All rights Reserved. 2018</span>
    </div>
  </footer>
)

export default FooterNav