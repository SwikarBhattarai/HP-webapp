import React, { Component } from 'react'

 class StudentHomePage extends Component {
  render() {
    return (
      <div>
        Student Home Page
      </div>
    )
  }
}

export default StudentHomePage
