import React, { Component } from 'react'
import { connect } from 'react-redux'
import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,
  NavLink,
  Button,
  UncontrolledDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem } from 'reactstrap'

import {Link} from 'react-router-dom'

import './style.css'

class Header extends Component {
  constructor(props) {
    super(props)

    this.toggle = this.toggle.bind(this)
    this.state = {
      isOpen: false
    }
  }
  toggle() {
    this.setState({
      isOpen: !this.state.isOpen
    })
  }
 
  renderContent(){
    switch(this.props.auth){
      case null:
        return 
      case false:
        return (
          <div className="nav">
          <NavLink href="/signup"><Button color="info">Sign Up</Button></NavLink>
          <NavLink href="/login"><Button color="info">Login</Button></NavLink>
          </div>
        )
       
        
        
      default:
        return  <NavLink href="api/logout"><Button color="danger">Logout</Button></NavLink>
    }
  }

  render() {
    return (
      <div>
        <Navbar color="navbar navbar-dark bg-dark" expand="md">
          <NavbarBrand><Link to={this.props.auth ? '/home' : '/'}>Hamro Paathsala</Link></NavbarBrand>
          <NavbarToggler onClick={this.toggle} />
          <Collapse isOpen={this.state.isOpen} navbar>
            <Nav className="ml-auto" navbar>
              {/* <NavItem>
                <NavLink href="/">Getting Started</NavLink>
              </NavItem> */}
              <NavItem>
                {this.renderContent()}
              </NavItem>
              {/* <UncontrolledDropdown nav inNavbar>
                <DropdownToggle nav caret>
                  Options
                </DropdownToggle>
                <DropdownMenu right>
                  <DropdownItem>
                    Option 1
                  </DropdownItem>
                  <DropdownItem>
                    Option 2
                  </DropdownItem>
                  <DropdownItem divider />
                  <DropdownItem>
                    Reset
                  </DropdownItem>
                </DropdownMenu>
              </UncontrolledDropdown> */}
            </Nav>
          </Collapse>
        </Navbar>
      </div>
    )
  }
}

function mapStateToProps({ auth }){
  return { auth };
}

export default connect (mapStateToProps) (Header)

